#!/bin/bash
#SBATCH -n 1
#SBATCH -N 1
#SBATCH -c 1
#SBATCH -t 0-11:55
#SBATCH -p short
#SBATCH --mem=300000
#SBATCH -o %j_out.txt
#SBATCH -e %j_err.txt

module load gcc/6.2.0 R/3.5.1 #Load R module
nohup R CMD BATCH --quiet --no-restore --no-save /home/jl762/xinzhou/MissingData/R_file/Processing233.R
