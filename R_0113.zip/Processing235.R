lam_set <- 0.25 * c(16:20)
load("uni_cell_id.RData")
library(Seurat)
library(Matrix)
library(data.table)
library(Matrix)
library(MASS)
library(flare)
library(clime)
library(matrixcalc)
library(fastclime)
library(ggplot2)
library(plyr)
library(stringr)
dyn.load("/home/jl762/xinzhou/Debiased_Estimation/Property_test/conn/dpm-master/dpm.so");
source("/home/jl762/xinzhou/Debiased_Estimation/Property_test/conn/dpm-master/dpm.R");
i_list <- c(1,3:18)
i <-15
cell_type <- uni_cell_id[i]
load(paste(cell_type,"_data500.RData",sep = ""))
dat_X <- dat_X[1:100,]
dat_Y <- dat_Y[1:100,]
dat_X_dim <- dim(dat_X)[2]
dat_Y_dim <- dim(dat_Y)[2]

dat_X_final <- apply(dat_X, 1, function(x){qnorm(rank(x)/(dim(dat_X)[2]+1))})
dat_Y_final <- apply(dat_Y, 1, function(x){qnorm(rank(x)/(dim(dat_Y)[2]+1))})

n11 <- floor(dat_X_dim/2)
n12 <- ceiling(dat_X_dim/2)
n21 <- floor(dat_Y_dim/2)
n22 <- ceiling(dat_Y_dim/2)
d <- dim(dat_X)[1]

dat1_X <- dat_X_final[1:(n11),]
dat2_X <- dat_X_final[(n11+1):(n11+n12),]
dat1_Y <- dat_Y_final[(1):(n21),]
dat2_Y <- dat_Y_final[(n21+1):(n21+n22),]

cov1_X <- cov(dat1_X) * (1-1/n11)
cov1_Y <- cov(dat1_Y) * (1-1/n21)
cov2_X <- cov(dat2_X) * (1-1/n12)
cov2_Y <- cov(dat2_Y) * (1-1/n22)

loss_m_mse <- c()
loss_f_mse <- c()
for (lam in lam_set){
  Delta_hat_1 <- dpm(dat1_X,dat1_Y,lambda=lam*sqrt(log(d)/max(n11,n12)),tuning="bic")$dpm[[1]]
  Delta_hat_2 <- dpm(dat2_X,dat2_Y,lambda=lam*sqrt(log(d)/max(n21,n22)),tuning="bic")$dpm[[1]]
  
  lossm <- 0.5*(norm(cov1_X%*%Delta_hat_1%*%cov1_Y-cov1_X+cov1_Y,type="M") +
                  norm(cov2_X%*%Delta_hat_1%*%cov2_Y-cov2_X+cov2_Y,type="M"))
  loss_m_mse <- c(loss_m_mse,lossm)
  lossf <- 0.5*(norm(cov1_X%*%Delta_hat_1%*%cov1_Y-cov1_X+cov1_Y,type="f") +
                  norm(cov2_X%*%Delta_hat_1%*%cov2_Y-cov2_X+cov2_Y,type="f"))
  loss_f_mse <- c(loss_f_mse,lossf)
  save(lossm,lossf, file=paste("Res/",cell_type,"_",lam*4,"_CV_mse.RData",sep = ""))
}
