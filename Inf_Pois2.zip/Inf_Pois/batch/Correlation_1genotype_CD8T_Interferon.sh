#!/bin/bash
#SBATCH -n 1
#SBATCH -N 1
#SBATCH -c 1
#SBATCH -t 0-11:55
#SBATCH -p shared
#SBATCH --mem=80000
#SBATCH -o %j_out.txt
#SBATCH -e %j_err.txt

module load R #Load R module
nohup R CMD BATCH --quiet --no-restore --no-save /n/home10/luzhu/xinzhou/MissingData/Rfile2/Correlation_1genotype_CD8T_Interferon.R
