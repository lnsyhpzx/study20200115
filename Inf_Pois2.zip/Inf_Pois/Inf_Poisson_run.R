source("./Inf_Poisson.R")

load("../data/fibroblast_Hedghog.RData")
dat_genes <- dat
load("../data/fibroblast_HHIP.RData")
dat_H <- matrix(dat,ncol=1)
res_genes <- Zero_Inflated_Poisson(dat_genes)
save(res_genes,file="Infl_fibroblast_Hedghog.RData")
res_H <- Zero_Inflated_Poisson(matrix(dat_H,ncol=1))
save(res_genes,res_H,file="Infl_fibroblast_Hedghog_HHIP.RData")

load("../data/fibroblast_Interferon.RData")
dat_genes <- dat
load("../data/fibroblast_HHIP.RData")
dat_H <- matrix(dat,ncol=1)
res_genes <- Zero_Inflated_Poisson(dat_genes)
save(res_genes,file="Infl_fibroblast_Interferon.RData")
res_H <- Zero_Inflated_Poisson(matrix(dat_H,ncol=1))
save(res_genes,res_H,file="Infl_fibroblast_Interferon_HHIP.RData")

load("../data/CD8T_Interferon.RData")
dat_genes <- dat
load("../data/CD8T_HHIP.RData")
dat_H <- matrix(dat,ncol=1)
res_genes <- Zero_Inflated_Poisson(dat_genes)
save(res_genes,file="Infl_CD8T_Interferon.RData")
res_H <- Zero_Inflated_Poisson(matrix(dat_H,ncol=1))
save(res_genes,res_H,file="Infl_CD8T_Interferon_HHIP.RData")


