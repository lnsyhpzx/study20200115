library(pscl)
expit <- function(a){exp(a)/(exp(a)+1)}

load("../data/CD8T_Interferon.RData")


#i<-2
N <- dim(dat)[2]
Zero_Inf_Poi_Reg <- function(i){
  if (sum(dat[,i])==0){return(c(1,0,0,1))}
  M1 <- zeroinfl(dat[,i]~cell_geno_num|1, dist = 'poisson')
  pi_hat <- expit(as.numeric(M1$coefficients$zero))
  lambda1_hat <-exp(as.numeric(M1$coefficients$count[1]))
  lambda2_hat <-exp(as.numeric(M1$coefficients$count[1]+M1$coefficients$count[2]))
  p_val_lambda <- summary(M1)$`coefficients`$`count`[2,4]
  print(i)
  return(c(pi_hat,lambda1_hat,lambda2_hat,p_val_lambda))
}
res <- sapply(1:N,Zero_Inf_Poi_Reg)
res_out <- t(rbind(res[1:3,], p.adjust(res[4,],"bonferroni")))
save(res_out, file="CD8T_Interferon_ZeroInfPoi.RData")




load("../data/fibroblast_Hedghog.RData")
N <- dim(dat)[2]
res <- sapply(1:N,Zero_Inf_Poi_Reg)
res_out <- t(rbind(res[1:3,], p.adjust(res[4,],"bonferroni")))
save(res_out, file="fibroblast_Hedghog_ZeroInfPoi.RData")



load("../data/fibroblast_Interferon.RData")
N <- dim(dat)[2]
res <- sapply(1:N,Zero_Inf_Poi_Reg)
res_out <- t(rbind(res[1:3,], p.adjust(res[4,],"bonferroni")))
save(res_out, file="fibroblast_Interferon_ZeroInfPoi.RData")

load("../data/fibroblast_HHIP.RData")
dat <- matrix(dat,ncol=1)
N <- dim(dat)[2]
res <- sapply(1:N,Zero_Inf_Poi_Reg)
res_HHIP <- res
save(res_HHIP, file="fibroblast_HHIP.RData")

load("../data/CD8T_HHIP.RData")
dat <- matrix(dat,ncol=1)
N <- dim(dat)[2]
res <- sapply(1:N,Zero_Inf_Poi_Reg)
res_HHIP <- res
save(res_HHIP, file="CD8T_HHIP.RData")

