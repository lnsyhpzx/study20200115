library(pscl)
library(Matrix)

load("./data/CD8T_Interferon.RData")
dat_genes <- dat
load("./data/CD8T_HHIP.RData")
dat_H <- dat


Zero_Inflated_Poisson_1genotype <- function(dat_genes,dat_H, Rep_times=100){
  
  ############zero inflated poisson GLM
  Zero_Inf_Poi_Reg <- function(i,dat){
    expit <- function(a){exp(a)/(exp(a)+1)}
    if (sum(dat[,i])==0){return(c(1,0))}
    M1 <- zeroinfl(dat[,i]~1|1, dist = 'poisson')
    pi_hat <- expit(as.numeric(M1$coefficients$zero))
    lambda_hat <-exp(as.numeric(M1$coefficients$count[1]))
    return(c(pi_hat,lambda_hat))
  }
  
  zero_inf_genes <- sapply(1:(dim(dat_genes)[2]),function(t){Zero_Inf_Poi_Reg(t,dat_genes)})
  res_out <- t(zero_inf_genes[1:2,])
  zero_inf_H <- Zero_Inf_Poi_Reg(1,matrix(dat_H,ncol=1))
  
  #############correlation
  res_geno1_cov_star <- apply(dat_genes,2,function(x){cov(x,dat_H)})
  res_geno1_cor <- res_geno1_cov_star/sqrt(zero_inf_genes[2,]*zero_inf_H[2])/(1-zero_inf_genes[1,])/(1-zero_inf_H[1])
  res_geno1_cor[is.na(res_geno1_cor)] <- 0 
  
  
  ###########bootstrap
  boot_computing_correlation <- function(dat_gene1, dat_gene2, cor1){
    n1 <- length(dat_gene2)
    cell_geno_num_vec <- c(rep(0,n1))
    zero_inf_gene1 <- Zero_Inf_Poi_Reg(1,matrix(dat_gene1,ncol=1))
    zero_inf_gene2 <- Zero_Inf_Poi_Reg(1,matrix(dat_gene2,ncol=1))
    res_geno1_cor_boot <- cov(dat_gene1,dat_gene2)/sqrt(zero_inf_gene1[2]*zero_inf_gene2[2])/(1-zero_inf_gene1[1])/(1-zero_inf_gene2[1])
    res_output <- c(abs(res_geno1_cor_boot)>abs(cor1))
    res_output[is.na(res_geno1_cor_boot)] <- 0
    res_output[c(cor1==0)] <- 1
    res_output <- c(res_output, zero_inf_gene1[1:2])
    return(res_output)
  }

  n1 <- length(dat_H)
  boot_run_i <- function(i){
    dat_geno1_gene <- dat_genes[ ,i]; 
    dat_geno1_H <- dat_H; 
    ind_geno1_sampling <- sample(1:n1, n1*Rep_times, replace = T)
    
    boot_run_r <- function(r){
      dat_gene1 <- c(dat_geno1_gene[ind_geno1_sampling[((r-1)*n1+1):(r*n1)]])
      dat_geneH <- c(dat_geno1_H[ind_geno1_sampling[((r-1)*n1+1):(r*n1)]])
      res <- boot_computing_correlation(dat_gene1=dat_gene1,dat_gene2=dat_geneH,
                                        cor1=res_geno1_cor[i])
      return(res)
    }
    
    res_boot <- sapply(1:Rep_times,function(r){boot_run_r(r)})
    res_boot_cor <- mean(res_boot[1,])
    return(res_boot_cor)
  }
  res_cor_genes <- sapply(1:dim(dat_genes)[2], boot_run_i)
  res_out <- cbind(res_out,res_geno1_cor,(res_cor_genes),p.adjust(res_cor_genes))
  return(res_out)
}

res <- Zero_Inflated_Poisson_1genotype(dat_genes,dat_H)
save(res,file="Correlation_1genotype_CD8T_Interferon.RData")