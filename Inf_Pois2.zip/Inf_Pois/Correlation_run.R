source("Correlation.R")
load("Infl_fibroblast_Hedghog_HHIP.RData")
load("../data/fibroblast_Hedghog.RData")
dat_genes <- dat
load("../data/fibroblast_HHIP.RData")
dat_H <- (dat)
outp <- correlation_test(dat_genes,res_genes,dat_H,res_H)
write.csv(outp,file = "./output/fibroblast_Hedghog_HHIP.csv", row.names =T, quote =F)

load("Infl_fibroblast_Interferon_HHIP.RData")
load("../data/fibroblast_Interferon.RData")
dat_genes <- dat
load("../data/fibroblast_HHIP.RData")
dat_H <- (dat)
outp <- correlation_test(dat_genes,res_genes,dat_H,res_H)
write.csv(outp,file = "./output/fibroblast_Interferon_HHIP.csv", row.names =T, quote =F)

load("Infl_CD8T_Interferon_HHIP.RData")
load("../data/CD8T_Interferon.RData")
dat_genes <- dat
load("../data/CD8T_HHIP.RData")
dat_H <- (dat)
outp <- correlation_test(dat_genes,res_genes,dat_H,res_H)
write.csv(outp,file = "./output/CD8T_Interferon_HHIP.csv", row.names =T, quote =F)

