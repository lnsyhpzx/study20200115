library(Seurat)
library(Matrix)
library(data.table)
library(tidyverse)
library(parallel)
load("dat_before_Magic.RData")
load("Preprocessing.RData")
dat <- t(dat)
#dat<-dat[1:500,1:450]
#cell_id <- cell_id[1:450]
#cell_genotype <- cell_genotype[1:450]
###################Processing (t-test)
i <-2 
cell_type <- unique(cell_id)[i]
Het_ind <- which((cell_id==cell_type)&(cell_genotype==unique(cell_genotype)[1]))
Wt_ind <- which((cell_id==cell_type)&(cell_genotype==unique(cell_genotype)[2]))
dat_Het <- as.matrix(dat[,Het_ind])
dat_Wt <- as.matrix(dat[,Wt_ind])
cl <- makeCluster(detectCores())
dat_gene_ind_part<- clusterSplit(cl, 1:dim(dat_Wt)[1])
clusterExport(cl,"dat_Het")
clusterExport(cl,"dat_Wt")
p_dif <- unlist(parSapply(cl, dat_gene_ind_part, 
                          function(x){
                            sapply(x,function(i){t.test(dat_Het[i,],dat_Wt[i,])$p.value})}))
r_p_dif <- rank(p_dif,ties.method = "random")
dif_gene <- match(sort(r_p_dif, decreasing = F)[1:100], r_p_dif)
dif_gene <- sapply(dif_gene,function(x){if (is.na(x)){return(FALSE)} else {return(x)}})
dat_X <- dat[dif_gene,Het_ind]
dat_Y <- dat[dif_gene,Wt_ind]
save(dat_X, dat_Y, p_dif, file=paste(i,"_data.RData",sep = ""))
#dif_gene <- unlist(sapply(1:200, function(x){if ((mean(dat_X[x,]==0)<0.8)&(mean(dat_Y[x,]==0)<0.8)){return (x)}}))[1:20]
#dat_X <- dat_X[dif_gene,]
#dat_Y <- dat_Y[dif_gene,]

