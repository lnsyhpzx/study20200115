d_set <- c(100)
i0 <- 13
al <- 13
lam <- al/4
load("uni_cell_id.RData")
cell_type <- uni_cell_id[i0]
load(file=paste(cell_type,"_",lam*4,"_edge.RData",sep = ""))
edge_vec

for (d in d_set){
  library(Seurat)
  library(Matrix)
  library(data.table)
  library(Matrix)
  library(MASS)
  library(flare)
  library(clime)
  library(matrixcalc)
  library(fastclime)
  library(ggplot2)
  library(plyr)
  library(stringr)
  load(paste("Res/",cell_type,"_",lam*4,"_CV_mse.RData",sep = ""))
  dyn.load("/home/jl762/xinzhou/Debiased_Estimation/Property_test/conn/dpm-master/dpm.so");
  source("/home/jl762/xinzhou/Debiased_Estimation/Property_test/conn/dpm-master/dpm.R");
  
  R_boot <- 200
  alp <- 0.05
  load(paste(cell_type,"_data500.RData",sep = ""))
  dat_X <- dat_X[1:100,]
  dat_Y <- dat_Y[1:100,]
  dat_X_dim <- dim(dat_X)[2]
  dat_Y_dim <- dim(dat_Y)[2]
  
  dat_X_final <- apply(dat_X, 1, function(x){qnorm(rank(x)/(dim(dat_X)[2]+1))})
  dat_Y_final <- apply(dat_Y, 1, function(x){qnorm(rank(x)/(dim(dat_Y)[2]+1))})
  
  n11 <- floor(dat_X_dim/2)
  n12 <- ceiling(dat_X_dim/2)
  n21 <- floor(dat_Y_dim/2)
  n22 <- ceiling(dat_Y_dim/2)
  d <- dim(dat_X)[1]
  
  dat1_X <- dat_X_final[1:(n11),]
  dat2_X <- dat_X_final[(n11+1):(n11+n12),]
  dat1_Y <- dat_Y_final[(1):(n21),]
  dat2_Y <- dat_Y_final[(n21+1):(n21+n22),]
  
  cov1_X <- cov(dat1_X) * (1-1/n11)
  cov1_Y <- cov(dat1_Y) * (1-1/n21)
  cov2_X <- cov(dat2_X) * (1-1/n12)
  cov2_Y <- cov(dat2_Y) * (1-1/n22)
  Delta_hat <- dpm(dat1_X,dat1_Y,lambda=lam*sqrt(log(d)/max(n11,n12)),tuning="bic")$dpm[[1]]
  
  V_X <- t(clime(dat2_X,lambda=0.5*sqrt(log(d)/n21))$Omegalist[[1]])
  V_Y <- t(clime(dat2_Y,lambda=0.5*sqrt(log(d)/n22))$Omegalist[[1]])
  Delta_debiased_mat <- (Delta_hat
                         - V_Y %*% (cov1_Y %*% Delta_hat %*% cov1_X - (cov1_X-cov1_Y))
                         %*% t(V_X))
  
  xi_2 <- matrix(rep(0,d^2),nrow=d)
  for (j in 1:d){
    for (k in 1:d){
      xi_2[j,k] <- ((t((V_Y - Delta_hat)[j,]) %*% cov1_X %*% (V_Y - Delta_hat)[j,]
                     * t(V_X[k,]) %*% cov1_X %*% V_X[k,])
                    +(t((V_Y - Delta_hat)[j,]) %*% cov1_X %*% V_X[k,])^2
                    +n11/n21*(t(V_Y[j,]) %*% cov1_Y %*% V_Y[j,]
                              * t((V_X + Delta_hat)[k,]) %*% cov1_Y %*% (V_X + Delta_hat)[k,])
                    +n11/n21*(t(V_Y[j,]) %*% cov1_Y %*% (V_X + Delta_hat)[k,])^2)
    }
  }
  
  CI_low <- Delta_debiased_mat - sqrt(xi_2/n11) * qnorm(0.975)
  CI_upp <- Delta_debiased_mat + sqrt(xi_2/n11) * qnorm(0.975)
  
  res1 <- CI_low
  res1[CI_low>0] <- 1
  res1[CI_low<0] <- 0
  res2 <- CI_upp
  res2[CI_upp<0] <- 1
  res2[CI_upp>0] <- 0
  res <- res1+res2
  res <- res + t(res)
  
  j_set <- c()
  k_set <- c()
  for(j in 1:d){
    for (k in 1:d){
      if (res[j,k]>0){
        j_set <- c(j_set,j)
        k_set <- c(k_set,k)
      }
    }
  }
  
  
  
  edge_vec <- c() 
  
  repeat{
    get_critical_vec <- function(edge_vec){
      complete_vec <- c(sapply(1:d, function(i){sapply(1:d, function(j){return(paste(i,"_",j,sep = ""))})}))
      return(setdiff(complete_vec,edge_vec))
    }
    critical_vec <- get_critical_vec(edge_vec)
    coeff_data <- function(single_edge){
      j <- as.numeric(strsplit(single_edge,"_")[[1]])[1]
      k <- as.numeric(strsplit(single_edge,"_")[[1]])[2]
      res1 <- sapply(1:n11, 
                     function(i){
                       return((t((V_Y - Delta_hat)[j,]) %*% (dat1_X[i,] %*% t(dat1_X[i,]) - cov1_X) %*%
                                 V_X[k,])/sqrt(n11))
                     })
      res2 <- sapply(1:n21, 
                     function(i){
                       return(-(t(V_Y[j,]) %*% (dat1_Y[i,] %*% t(dat1_Y[i,]) - cov1_Y) %*%
                                  (V_X + Delta_hat)[k,])*sqrt(n11)/n21)
                     })
      return(c(res1,res2))
    }
    coeff_matrix_data <- t(sapply(critical_vec, coeff_data)) # n_e * n matrix
    xi_matrix <- matrix(rnorm((n11+n21)*R_boot), nrow=(n11+n21)) # n * R_boot matrix
    T_B <- apply(coeff_matrix_data %*% xi_matrix, 2, max)
    c_alpha_E <- sort(abs(T_B), decreasing = T)[floor(R_boot*alp)+1]
    test_stats <- sapply(critical_vec, 
                         function(e){
                           j <- as.numeric(strsplit(e,"_")[[1]])[1]
                           k <- as.numeric(strsplit(e,"_")[[1]])[2]
                           return(sqrt(n11)*abs(Delta_debiased_mat[j,k]))
                         })
    reject_vec <- names(test_stats[which(test_stats > c_alpha_E)])
    edge_vec <- c(edge_vec, reject_vec)
    if ((length(reject_vec) == 0)){ break}
  }
  save(edge_vec, file=paste("edge/",cell_type,"_",lam*4,"_edge.RData",sep = ""))
}
