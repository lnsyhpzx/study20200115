load("./res/Correlation_2genotypes_fibroblast_Hedghog.RData")
res <- cbind(res[,1:6], p.adjust(res[,6]),res[,7],p.adjust(res[,7]))
save(res,file="Correlation_2genotypes_fibroblast_Hedghog.RData")

load("./res/Correlation_2genotypes_fibroblast_Interferon.RData")
res <- cbind(res[,1:6], p.adjust(res[,6]),res[,7],p.adjust(res[,7]))
save(res,file="Correlation_2genotypes_fibroblast_Interferon.RData")
