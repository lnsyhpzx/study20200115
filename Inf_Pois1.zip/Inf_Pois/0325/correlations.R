load("fibroblast_Interferon_ZeroInfPoi.RData")
load("fibroblast_HHIP.RData")
load("../data/fibroblast_Interferon.RData")
dat_f <- dat
load("../data/fibroblast_HHIP.RData")
dat_HHIP <- dat
ind_Wt <- (cell_geno_num==1)
ind_Het <- (cell_geno_num==0)
res_Wt_cov_star <- apply(dat_f[ind_Wt,],2,function(x){cov(x,dat_HHIP[ind_Wt])})
res_Wt_var_mid <- (apply(dat_f[ind_Wt,],2,var)*(1-res_out[,1])
               -res_out[,1]*apply(dat_f[ind_Wt,],2,mean))
res_Wt_var_HHIP_mid <- (var(dat_HHIP[ind_Wt])*(1-res_HHIP[1])
                    -res_HHIP[1]*mean(dat_HHIP[ind_Wt]))
res_Wt_cor <- res_Wt_cov_star/sqrt(res_Wt_var_mid*res_Wt_var_HHIP_mid)

res_Het_cov_star <- apply(dat_f[ind_Het,],2,function(x){cov(x,dat_HHIP[ind_Het])})
res_Het_var_mid <- (apply(dat_f[ind_Het,],2,var)*(1-res_out[,1])
                   -res_out[,1]*apply(dat_f[ind_Het,],2,mean))
res_Het_var_HHIP_mid <- (var(dat_HHIP[ind_Het])*(1-res_HHIP[1])
                        -res_HHIP[1]*mean(dat_HHIP[ind_Het]))
res_Het_cor <- res_Het_cov_star/sqrt(res_Het_var_mid*res_Het_var_HHIP_mid)

save(res_Wt_cor,res_Het_cor,file="fibroblast_Interferon_cor.RData")
