library(pscl)
library(Matrix)

load("./data/fibroblast_Hedghog.RData")
dat_genes <- dat
load("./data/fibroblast_HHIP.RData")
dat_H <- dat
Rep_times <- 100
cell_genotype <- cell_geno_num


Zero_Inflated_Poisson_2genotypes <- function(dat_genes,dat_H, cell_genotype, Rep_times=100){
  
  ############zero inflated poisson GLM
  Zero_Inf_Poi_Reg <- function(i,dat,cell_geno_num){
    expit <- function(a){exp(a)/(exp(a)+1)}
    if (sum(dat[,i])==0){return(c(1,0,0,1))}
    M1 <- zeroinfl(dat[,i]~cell_geno_num|1, dist = 'poisson')
    pi_hat <- expit(as.numeric(M1$coefficients$zero))
    lambda1_hat <-exp(as.numeric(M1$coefficients$count[1]))
    lambda2_hat <-exp(as.numeric(M1$coefficients$count[1]+M1$coefficients$count[2]))
    p_val_lambda <- summary(M1)$`coefficients`$`count`[2,4]
    return(c(pi_hat,lambda1_hat,lambda2_hat,p_val_lambda))
  }
  
  cell_geno_num <- (unique(cell_genotype)[2]==cell_genotype)
  zero_inf_genes <- sapply(1:(dim(dat_genes)[2]),function(t){Zero_Inf_Poi_Reg(t,dat_genes,cell_geno_num)})
  res_out <- t(rbind(zero_inf_genes[1:4,], p.adjust(zero_inf_genes[4,],"bonferroni")))
  zero_inf_H <- Zero_Inf_Poi_Reg(1,matrix(dat_H,ncol=1),cell_geno_num)
  
  #############correlation
  ind_genotype_1 <- (cell_geno_num==0)
  res_geno1_cov_star <- apply(dat_genes[ind_genotype_1,],2,function(x){cov(x,dat_H[ind_genotype_1])})
  res_geno1_cor <- res_geno1_cov_star/sqrt(zero_inf_genes[2,]*zero_inf_H[2])/(1-zero_inf_genes[1,])/(1-zero_inf_H[1])
  res_geno1_cor[is.na(res_geno1_cor)] <- 0
  ind_genotype_2 <- !(ind_genotype_1)
  res_geno2_cov_star <- apply(dat_genes[ind_genotype_2,],2,function(x){cov(x,dat_H[ind_genotype_2])})
  res_geno2_cor <- res_geno2_cov_star/sqrt(zero_inf_genes[3,]*zero_inf_H[3])/(1-zero_inf_genes[1,])/(1-zero_inf_H[1])
  res_geno2_cor[is.na(res_geno2_cor)] <- 0
  
  ###########bootstrap
  boot_computing_correlation <- function(dat_gene1, dat_gene2, n1, cor1, cor2){
    n2 <- length(dat_gene2)-n1
    cell_geno_num_vec <- c(rep(0,n1),rep(1,n2))
    zero_inf_gene1 <- Zero_Inf_Poi_Reg(1,matrix(dat_gene1,ncol=1),cell_geno_num_vec)
    zero_inf_gene2 <- Zero_Inf_Poi_Reg(1,matrix(dat_gene2,ncol=1),cell_geno_num_vec)
    res_geno1_cor_boot <- cov(dat_gene1[1:n1],dat_gene2[1:n1])/sqrt(zero_inf_gene1[2]*zero_inf_gene2[2])/(1-zero_inf_gene1[1])/(1-zero_inf_gene2[1])
    res_geno2_cor_boot <- cov(dat_gene1[(n1+1):(n1+n2)],dat_gene2[(n1+1):(n1+n2)])/sqrt(zero_inf_gene1[3]*zero_inf_gene2[3])/(1-zero_inf_gene1[1])/(1-zero_inf_gene2[1])
    res_output <- c(abs(res_geno1_cor_boot)>abs(cor1), abs(res_geno2_cor_boot)>abs(cor2))
    res_output[c(is.na(res_geno1_cor_boot), is.na(res_geno2_cor_boot))] <- 0
    res_output[c(cor1==0,cor2==0)] <- 1
    res_output <- c(res_output, zero_inf_gene1[1:3])
    return(res_output)
  }
  
  n2 <- sum(cell_geno_num)
  n1 <- length(dat_H)-n2
  
  boot_run_i <- function(i){
    dat_geno1_gene <- dat_genes[ind_genotype_1 ,i]; dat_geno2_gene <- dat_genes[ind_genotype_2 ,i]
    dat_geno1_H <- dat_H[ind_genotype_1]; dat_geno2_H  <- dat_H[ind_genotype_2]
    ind_geno1_sampling <- sample(1:n1, n1*Rep_times, replace = T)
    ind_geno2_sampling <- sample(1:n2, n2*Rep_times, replace = T)
    
    boot_run_r <- function(r){
      dat_gene1 <- c(dat_geno1_gene[ind_geno1_sampling[((r-1)*n1+1):(r*n1)]],
                     dat_geno2_gene[ind_geno2_sampling[((r-1)*n2+1):(r*n2)]])
      dat_geneH <- c(dat_geno1_H[ind_geno1_sampling[((r-1)*n1+1):(r*n1)]],
                     dat_geno2_H[ind_geno2_sampling[((r-1)*n2+1):(r*n2)]])
      res <- boot_computing_correlation(dat_gene1=dat_gene1,dat_gene2=dat_geneH,n1=n1,
                                        cor1=res_geno1_cor[i],cor2=res_geno2_cor[i])
      return(res)
    }
    
    res_boot <- sapply(1:Rep_times,function(r){boot_run_r(r)})
    res_boot_cor <- apply(res_boot[1:2,],1,mean)
    return(res_boot_cor)
  }
  res_cor_genes <- sapply(1:dim(dat_genes)[2], boot_run_i)
  res_out <- cbind(res_out,res_geno1_cor,res_cor_genes[1,],p.adjust(res_cor_genes[1,]),
                   res_geno2_cor, res_cor_genes[2,],p.adjust(res_cor_genes[2,]))
  return(res_out)
}

res <- Zero_Inflated_Poisson_2genotypes(dat_genes,dat_H, cell_genotype)
save(res,file="Correlation_2genotypes_fibroblast_Hedghog.RData")