load("Inf_Pois_res.RData")
load("Par_bootstrap.RData")
outp <- rbind(c("Cell_Type",names(pi_H)),
              c("Het",lambda_H),
              c("Wt",lambda_W),
              c("Equal",res<=95))
# when pi is very large, not good N,R?

write.table (outp, file ="lambdas.txt", sep ="\t", row.names =F, col.names =F, quote =F)

