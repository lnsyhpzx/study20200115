lambda_H <- c(); lambda_W <- c()
pi_H <- c(); pi_W <- c()
for (j in 1:20){
  load(paste("res_",j,".RData",sep=""))
  lambda_H <- c(lambda_H,res_H[1,])
  lambda_W <- c(lambda_W,res_W[1,])
  pi_H <- c(pi_H,res_H[2,])
  pi_W <- c(pi_W,res_W[2,])
}

save(lambda_H,lambda_W,pi_H,pi_W,
     file="Inf_Pois_res.RData")
