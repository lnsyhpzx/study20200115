load("Inf_Pois_res.RData")
library(VGAM)


Inf_Poisson_Est <- function(y){
  sigma2 <- var(y)
  mu <- mean(y)
  lambda <- (sigma2+mu^2)/mu-1
  pi <- (sigma2-mu)/(sigma2-mu+mu^2)
  return(c(lambda,pi))
}

Par_bootstrap <- function(lambda1,pi1,lambda2,pi2,n=100){
  if (is.na(lambda1-lambda2)){return (T)}
  sam_H <- rzipois(n, lambda = lambda1, pstr0 = pi1)
  sam_W <- rzipois(n, lambda = lambda2, pstr0 = pi2)
  res_lam <- Inf_Poisson_Est(sam_H)[1]-Inf_Poisson_Est(sam_W)[1]
  if (is.na(res_lam)){return (F)}
  return (abs(lambda1-lambda2)>abs(res_lam))
}

R<-100
res <- c()
for (i in 1:length(lambda_H)){
  res0 <- sum(sapply(1:R,function(x){Par_bootstrap(lambda_H[i],pi_H[i],lambda_W[i],pi_W[i])}))
  res <- c(res,res0)
}

save(res, file="Par_bootstrap.RData")

