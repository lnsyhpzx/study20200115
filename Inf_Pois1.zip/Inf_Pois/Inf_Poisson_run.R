source("./Inf_Poisson.R")

load("../data/fibroblast_Hedghog.RData")
dat_genes <- dat
load("../data/fibroblast_HHIP.RData")
dat_H <- matrix(dat,ncol=1)
(sum(dat_genes[cell_geno_num==0,]))==0
(sum(dat_genes[cell_geno_num==1,]))==0
res_genes <- Zero_Inflated_Poisson(dat_genes,cell_geno_num)
save(res_genes,file="Infl_fibroblast_Hedghog.RData")
(sum(dat_H[cell_geno_num==0,]))==0
(sum(dat_H[cell_geno_num==1,]))==0
res_H <- Zero_Inflated_Poisson(matrix(dat_H[cell_geno_num==0,],ncol=1))
res_genes <- res_genes[,1:2]
save(res_genes,res_H,file="Infl_fibroblast_Hedghog_HHIP_Ht.RData")


load("../data/fibroblast_Interferon.RData")
dat_genes <- dat
load("../data/fibroblast_HHIP.RData")
dat_H <- matrix(dat,ncol=1)
(sum(dat_genes[cell_geno_num==0,]))==0
(sum(dat_genes[cell_geno_num==1,]))==0
res_genes <- Zero_Inflated_Poisson(dat_genes,cell_geno_num)
save(res_genes,file="Infl_fibroblast_Interferon.RData")
(sum(dat_H[cell_geno_num==0,]))==0
(sum(dat_H[cell_geno_num==1,]))==0
res_H <- Zero_Inflated_Poisson(matrix(dat_H[cell_geno_num==0,],ncol=1))
res_genes <- res_genes[,1:2]
save(res_genes,res_H,file="Infl_fibroblast_Interferon_HHIP_Ht.RData")


load("../data/CD8T_Interferon.RData")
dat_genes <- dat
load("../data/CD8T_HHIP.RData")
dat_H <- matrix(dat,ncol=1)
(sum(dat_genes[cell_geno_num==0,]))==0
(sum(dat_genes[cell_geno_num==1,]))==0
res_genes <- Zero_Inflated_Poisson(dat_genes,cell_geno_num)
save(res_genes,file="Infl_CD8T_Interferon.RData")
(sum(dat_H[cell_geno_num==0,]))==0
(sum(dat_H[cell_geno_num==1,]))==0


