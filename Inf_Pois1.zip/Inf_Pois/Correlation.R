correlation_test <- function(dat_genes,res_genes,dat_H,res_H){
  compute_correlation <- function(dat_genes,res_genes,dat_H,res_H){
    p <- dim(dat_genes)[2]
    N <- dim(dat_genes)[1]
    res_cov_star <- apply(dat_genes,2,function(x){cov(x,dat_H)})
    coef_dom <- sqrt(res_genes[,2]*res_H[2])*(1-res_genes[,1])*(1-res_H[1])
    res_cor <- res_cov_star/coef_dom
    res_cor[is.na(res_cor)] <- 0
    est_var <- function(X,Y,EX,EY,CovXY){
      N <- length(X)
      return(1/N * sum(((X-EX)*(Y-EY)-CovXY)^2))
    }
    var_res_cov_star <- sapply(1:p, 
                               function(j){
                                 1/N * (est_var(dat_genes[,j],dat_H, 
                                                (1-res_genes[j,1])*res_genes[j,2],
                                                (1-res_H[1])*res_H[2],
                                                res_cov_star[j]))
                               })
    var_res_cor <- var_res_cov_star/(coef_dom)^2
    return(cbind(res_cor,var_res_cor))
  }
  
  
  compute_p_value <- function(res_cor,var_res_cor){
    get_p_value <- function(cor,var_cor,test_value = 0){
      if (is.na(var_cor)){return(var_cor)}
      W <- abs(cor-test_value)/sqrt(var_cor) 
      return((1-pnorm(W))*2)
    }
    p_val <- sapply(1:length(res_cor), function(p){get_p_value(res_cor[p],var_res_cor[p])})
    return(cbind(p_val,p.adjust(p_val)))
  }
  
  res_cor <- compute_correlation(dat_genes,res_genes,dat_H,res_H)
  res_p <- compute_p_value(res_cor[,1],res_cor[,2])
  outp <- cbind(res_cor,res_p)
  colnames(outp) <- c("correlation", "variance", "p_value", "adjusted_p_value")
  return(outp)
}



