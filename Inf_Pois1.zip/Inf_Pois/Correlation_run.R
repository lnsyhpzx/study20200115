source("Correlation.R")
load("Infl_fibroblast_Hedghog_HHIP_Ht.RData")
load("../data/fibroblast_Hedghog.RData")
dat_genes <- dat[cell_geno_num==0,]
load("../data/fibroblast_HHIP.RData")
dat_H <- (dat[cell_geno_num==0])
outp <- correlation_test(dat_genes,res_genes,dat_H,res_H)
write.csv(outp,file = "./output/fibroblast_Hedghog_HHIP_Ht.csv", row.names =T, quote =F)

load("Infl_fibroblast_Interferon_HHIP_Ht.RData")
load("../data/fibroblast_Interferon.RData")
dat_genes <- dat[cell_geno_num==0,]
load("../data/fibroblast_HHIP.RData")
dat_H <- (dat[cell_geno_num==0])
outp <- correlation_test(dat_genes,res_genes,dat_H,res_H)
write.csv(outp,file = "./output/fibroblast_Interferon_HHIP_Ht.csv", row.names =T, quote =F)
