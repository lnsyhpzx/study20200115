library(pscl)
library(Matrix)



Zero_Inflated_Poisson <- function(dat_genes,cell_genotype=NULL){
  
  ############zero inflated poisson GLM
  Zero_Inf_Poi_Reg1 <- function(i,dat){
    expit <- function(a){exp(a)/(exp(a)+1)}
    if (sum(dat[,i])==0){return(c(1,0))}
    M1 <- zeroinfl(dat[,i]~1|1, dist = 'poisson')
    pi_hat <- expit(as.numeric(M1$coefficients$zero))
    lambda_hat <-exp(as.numeric(M1$coefficients$count[1]))
    return(c(pi_hat,lambda_hat))
  }
  
  Zero_Inf_Poi_Reg2 <- function(i,dat,cell_geno_num){
    expit <- function(a){exp(a)/(exp(a)+1)}
    if (sum(dat[,i])==0){return(c(1,0,0,1))}
    M1 <- zeroinfl(dat[,i]~cell_geno_num|1, dist = 'poisson')
    pi_hat <- expit(as.numeric(M1$coefficients$zero))
    lambda1_hat <-exp(as.numeric(M1$coefficients$count[1]))
    lambda2_hat <-exp(as.numeric(M1$coefficients$count[1]+M1$coefficients$count[2]))
    p_val_lambda <- summary(M1)$`coefficients`$`count`[2,4]
    return(c(pi_hat,lambda1_hat,lambda2_hat,p_val_lambda))
  }
  if (length(cell_genotype)==0){
    zero_inf_genes <- sapply(1:(dim(dat_genes)[2]),function(t){Zero_Inf_Poi_Reg1(t,dat_genes)})
    res_out <- t(zero_inf_genes[1:2,])
    return(res_out)
  }
  if(length(unique(cell_genotype))==2){
    cell_geno_num <- (unique(cell_genotype)[2]==cell_genotype)
    zero_inf_genes <- sapply(1:(dim(dat_genes)[2]),function(t){Zero_Inf_Poi_Reg2(t,dat_genes,cell_geno_num)})
    res_out <- t(rbind(zero_inf_genes[1:4,], p.adjust(zero_inf_genes[4,],"bonferroni")))
    return(res_out)
  }
  return(NaN)
  
  
}
